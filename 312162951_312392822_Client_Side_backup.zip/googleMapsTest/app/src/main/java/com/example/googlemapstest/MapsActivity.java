package com.example.googlemapstest;

import java.io.*;
import java.net.*;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.example.googlemapstest.FetchURL;
import com.example.googlemapstest.TaskLoadedCallback;

import java.time.Clock;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Eylon and Saar on 2021/2022.
 */

class Example {
    public static DataInputStream in;
    public static DataOutputStream dout;
    public static Socket soc;
    public static String msg = "";
}


class receiveMsgFromServer extends Thread {
    public void run() {
        try {
            while (true) {
                Example.msg = (String) Example.in.readUTF();
                //System.out.println(Example.msg + " it's work");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback, TaskLoadedCallback {
    private GoogleMap mMap;
    private MarkerOptions place1, place2;
    Button getDirection;
    protected Polyline currentPolyline;
    Thread thread;
    Handler mymyhandler;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
                Log.e("Error" + Thread.currentThread().getStackTrace()[2], paramThrowable.getLocalizedMessage());
            }
        });
        setContentView(R.layout.activity_maps);


        getDirection = findViewById(R.id.btnShowTraffic);
        getDirection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDirection.setEnabled(false);
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                receiveMsgFromServer r = new receiveMsgFromServer();
                try {
                    Example.soc = new Socket("10.0.0.23", 9999);
                    Example.dout = new DataOutputStream(Example.soc.getOutputStream());
                    Example.in = new DataInputStream(Example.soc.getInputStream());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                r.start(); // starting thread
                new FetchURL(MapsActivity.this).execute(getUrl(place1.getPosition(), place2.getPosition(), "driving"), "driving");
            }
        });
        place1 = new MarkerOptions().position(new LatLng(33.01645, 35.10337)).title("Location 1");
        place2 = new MarkerOptions().position(new LatLng(33.01566, 35.10320)).title("Location 2");
        ///
        //new FetchURL(MapsActivity.this).execute("https://roads.googleapis.com/v1/speedLimits?path=38.75807927603043,-9.03741754643809|38.6896537,-9.1770515|41.1399289,-8.6094075&key=AIzaSyBqv9eeFOPw6s6xVtHyKsKJeMXdCdHGKf4");
        ///
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapNearBy);
        mapFragment.getMapAsync(this);
        ////////////////////////////////////////
        thread = new Thread(new MyMyThread());

        mymyhandler = new Handler() {
            @Override
            public void handleMessage(Message newmsg) {
                removeMessages(0);
                if (currentPolyline != null)
                    currentPolyline.remove();
                if (Example.msg.equals("False")) {
                    currentPolyline = mMap.addPolyline(new PolylineOptions()
                            .add(new LatLng(33.01645, 35.10337), new LatLng(33.01566, 35.10320))
                            .width(10)
                            .color(Color.GREEN));
                } else if (Example.msg.equals("True")) {
                    currentPolyline = mMap.addPolyline(new PolylineOptions()
                            .add(new LatLng(33.01645, 35.10337), new LatLng(33.01566, 35.10320))
                            .width(10)
                            .color(Color.RED));
                } else {
                    currentPolyline = mMap.addPolyline(new PolylineOptions()
                            .add(new LatLng(33.01645, 35.10337), new LatLng(33.01566, 35.10320))
                            .width(10)
                            .color(Color.BLUE));
                }
            }
        };
        thread.start();
    }

    class MyMyThread implements Runnable {
        @Override
        public void run() {

            //  msg.arg1 = 1;
            while (true) {
                Message newmsg = Message.obtain();
                mymyhandler.sendMessage(newmsg);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        Log.d("mylog", "Added Markers");
        mMap.addMarker(place1);
        mMap.addMarker(place2);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(33.01645, 35.10337), 17));

    /*    for (int i = 0; i <= 3; i++) {
            System.out.println("yesyeysysys" + new PlaceApi().placesAutoComplete("haifa"));
        }*/
    }

    private String getUrl(LatLng origin, LatLng dest, String directionMode) {
        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        // Mode
        String mode = "mode=" + directionMode;
        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        // Output format
        String output = "json";
        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + getString(R.string.google_maps_key);
        return url;
    }

    @Override
    public void onTaskDone(Object... values) {

    }


    public class PlaceApi {
        public ArrayList<String> placesAutoComplete(String input) {
            ArrayList<String> arrayList = new ArrayList<>();
            HttpURLConnection connection = null;
            StringBuilder jsonResult = new StringBuilder();
            try {
                StringBuilder stringBuilder = new StringBuilder("https://maps.googleapis.com/maps/api/place/autocomplete/json?");
                stringBuilder.append("input=" + input);
                stringBuilder.append("&key=AIzaSyAdUjHYFafxlvPIbtJGzjGoJzrKFgHJh64");
                URL url = new URL(stringBuilder.toString());
                connection = (HttpURLConnection) url.openConnection();
                //BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                InputStreamReader inputStreamReader = new InputStreamReader(connection.getInputStream());

                int read;
                char[] buffer = new char[1024];
                while ((read = inputStreamReader.read(buffer)) != -1) {
                    jsonResult.append(buffer, 0, read);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }

            try {
                JSONObject jsonObject = new JSONObject(jsonResult.toString());
                JSONArray predictions = jsonObject.getJSONArray("predictions");
                for (int i = 0; i < predictions.length(); i++) {
                    arrayList.add(predictions.getJSONObject(i).getString("description"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return arrayList;
        }
    }
}